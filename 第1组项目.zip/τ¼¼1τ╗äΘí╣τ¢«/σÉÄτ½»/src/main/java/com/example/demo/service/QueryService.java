package com.example.demo.service;

import com.example.demo.pojo.Result;

public interface QueryService {
    Result showPath(String id);

    Result showPortList();
}

package com.example.demo.pojo;

public class Node{
    public String in_time;
    public String out_time;
    public String port_name;
}

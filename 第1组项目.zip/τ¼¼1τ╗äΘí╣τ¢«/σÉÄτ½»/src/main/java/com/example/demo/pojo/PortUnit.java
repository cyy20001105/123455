package com.example.demo.pojo;

public class PortUnit {
    public String user;
    public String port;
    public PortUnit(String user,String port){
        this.user = user;
        this.port = port;
    }
}
